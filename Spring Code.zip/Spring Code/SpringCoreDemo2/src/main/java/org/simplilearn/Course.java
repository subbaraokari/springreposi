package org.simplilearn;

public class Course {
	private int cid;
	private String courseName;
	private int fee;

	public Course() {
		// TODO Auto-generated constructor stub
	}

	public Course(int cid, String courseName, int fee) {
		super();
		this.cid = cid;
		this.courseName = courseName;
		this.fee = fee;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public int getFee() {
		return fee;
	}

	public void setFee(int fee) {
		this.fee = fee;
	}

}
