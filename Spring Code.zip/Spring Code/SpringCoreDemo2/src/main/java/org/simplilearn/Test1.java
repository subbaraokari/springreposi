package org.simplilearn;

import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test1 {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("spring-beans3.xml");
		Quiz quiz=context.getBean(Quiz.class,"quiz");
		System.out.println("The question is");
		System.out.println(quiz.getQuestion());
		Map<String, String> answers=quiz.getAnswers();
		System.out.println("The answers are");
		Set<Map.Entry<String, String>> entries=answers.entrySet();
		for(Map.Entry<String, String> entry:entries)
			System.out.println(entry.getKey()+"----->"+entry.getValue());
		
	}

}
