package org.simplilearn.components;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("sportscomplex")
public class SportsComplex {
	private Coach coach;
	@Autowired(required = true)
	public SportsComplex(@Qualifier("baseBallCoach") Coach coach) {
		super();
		this.coach = coach;
	}
	public void train() {
		coach.teach();
	}
	
	
	
}
