package org.simplilearn.components;

public interface Coach {
	void teach();
}
