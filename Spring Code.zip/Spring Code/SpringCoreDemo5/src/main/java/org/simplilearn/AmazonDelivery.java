package org.simplilearn;

public class AmazonDelivery {
	private Courier courier;
	public AmazonDelivery(Courier courier) {
		this.courier=courier;
	}
	public void send(int pid)
	{
		courier.deliver(pid);
	}
}
