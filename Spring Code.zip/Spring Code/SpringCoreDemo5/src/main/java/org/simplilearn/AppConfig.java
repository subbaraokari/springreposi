package org.simplilearn;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	@Bean
	public Dtdc dtdc()
	{
		return new Dtdc();
	}
	@Bean
	public BlueDart blueDart() {
		return new BlueDart();
	}
	@Bean(name = "amazonDelivery")
	public AmazonDelivery amazonDelivery() {
		AmazonDelivery amazonDelivery=new AmazonDelivery(dtdc());
		return amazonDelivery;
	}
}
