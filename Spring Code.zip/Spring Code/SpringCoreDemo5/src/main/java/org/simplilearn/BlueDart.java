package org.simplilearn;

public class BlueDart implements Courier{
	@Override
	public void deliver(int pid) {
		System.out.println("The product with "+pid+" is delivered through bluedart");
	}

}
