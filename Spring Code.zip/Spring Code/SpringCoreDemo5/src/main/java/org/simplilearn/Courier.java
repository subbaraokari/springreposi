package org.simplilearn;

public interface Courier {
	void deliver(int pid);
}
