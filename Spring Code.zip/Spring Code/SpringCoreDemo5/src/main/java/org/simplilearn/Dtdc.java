package org.simplilearn;

public class Dtdc implements Courier{
	@Override
	public void deliver(int pid) {
		System.out.println("The product with "+pid+" is delivered through Dtdc");
	}

}
