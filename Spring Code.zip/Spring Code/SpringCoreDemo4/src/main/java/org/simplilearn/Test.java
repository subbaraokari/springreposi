package org.simplilearn;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		College college=context.getBean(College.class, "college");
		System.out.println(college.getCid()+"\t"+college.getCollegeName());
		System.out.println("The courses are");
		List<Course> courses=college.getCourses();
		for(Course course:courses)
			System.out.println(course.getCourseName()+"\t"+course.getFee());
	}

}
