package org.simplilearn;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	@Bean
	public Course course1() {
		return new Course(1, "java", 100);
	}
	@Bean
	public Course course2() {
		return new Course(2, ".net", 200);
	}
	@Bean
	public Course course3() {
		return new Course(3, "Python", 300);
	}
	@Bean
	public List<Course> courses(){
		List<Course> courses=new ArrayList<>();
		courses.add(course1());
		courses.add(course2());
		courses.add(course3());
		return courses;
	}
	@Bean(name = "college")
	public College college() {
		College college=new College();
		college.setCid(1);
		college.setCollegeName("simpli learn");
		college.setCourses(courses());
		return college;
	}
	
}
