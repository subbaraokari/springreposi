package org.simplilearn;

import java.util.List;

import org.simplilearn.config.AppConfig;
import org.simplilearn.dao.EmpDao;
import org.simplilearn.dao.EmpDaoImpl;
import org.simplilearn.entities.Emp;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		EmpDao dao=context.getBean(EmpDaoImpl.class, "empDao");
		List<Emp> employees=dao.getAll();
		for(Emp e:employees)
			System.out.println(e.getEno()+"\t"+e.getName()+"\t"+e.getAddress());
	}

}
