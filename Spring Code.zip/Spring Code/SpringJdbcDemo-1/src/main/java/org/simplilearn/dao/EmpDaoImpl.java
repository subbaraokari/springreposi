package org.simplilearn.dao;

import java.util.List;

import org.simplilearn.creators.EmpPreparedStatementCreator;
import org.simplilearn.entities.Emp;
import org.simplilearn.extractors.EmpExtractor;
import org.simplilearn.mappers.EmpRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component("empDao")
public class EmpDaoImpl implements EmpDao{
	private JdbcTemplate template;
	
	@Autowired
	public EmpDaoImpl(JdbcTemplate template) {
		super();
		this.template = template;
	}
	@Override
	public boolean insert(Emp e) {
		boolean isInserted=false;
		int i=template.update("insert into emp values(?,?,?)", e.getEno(),e.getName(),e.getAddress());
		if(i>0)
			isInserted=true;
		return isInserted;
	}

	@Override
	public boolean delete(int eno) {
		boolean isDeleted=false;
		int i=template.update("delete from emp where eno=?", eno);
		if(i>0)
			isDeleted=true;
		return isDeleted;
	}

	@Override
	public List<Emp> getAll() {
		List<Emp> employees=template.query("select * from emp", new EmpRowMapper());
		return employees;
	}

	@Override
	public Emp get(int eno) {
		//Emp e=template.query("select * from emp where eno=?", new Object[] {eno}, new EmpExtractor());
		Emp e=template.query(new EmpPreparedStatementCreator(eno), new EmpExtractor());
		return e;
	}

	@Override
	public void update(int eno, Emp e) {
		
	}

}
