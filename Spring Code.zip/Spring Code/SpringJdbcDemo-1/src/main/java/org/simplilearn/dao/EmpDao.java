package org.simplilearn.dao;

import java.util.List;

import org.simplilearn.entities.Emp;

public interface EmpDao {
	boolean insert(Emp e);
	boolean delete(int eno);
	List<Emp> getAll();
	Emp get(int eno);
	void update(int eno,Emp e);
}
