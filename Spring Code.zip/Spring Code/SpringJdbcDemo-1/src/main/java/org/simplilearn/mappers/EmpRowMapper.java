package org.simplilearn.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.simplilearn.entities.Emp;
import org.springframework.jdbc.core.RowMapper;

public class EmpRowMapper implements RowMapper<Emp>{
	@Override
	public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
		Emp e=new Emp();
		e.setEno(rs.getInt(1));
		e.setName(rs.getString(2));
		e.setAddress(rs.getString(3));
		return e;
	}
}
