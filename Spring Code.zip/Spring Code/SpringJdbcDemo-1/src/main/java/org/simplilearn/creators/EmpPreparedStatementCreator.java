package org.simplilearn.creators;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementCreator;

public class EmpPreparedStatementCreator implements PreparedStatementCreator{
	private int eno;
	public EmpPreparedStatementCreator(int eno) {
		this.eno=eno;
	}
	@Override
	public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
		PreparedStatement pst=con.prepareStatement("select * from emp where eno=?");
		pst.setInt(1, eno);
		return pst;
	}

}
