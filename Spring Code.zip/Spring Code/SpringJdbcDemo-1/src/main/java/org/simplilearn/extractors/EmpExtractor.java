package org.simplilearn.extractors;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.simplilearn.entities.Emp;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

public class EmpExtractor implements ResultSetExtractor<Emp>{
	
	@Override
	public Emp extractData(ResultSet rs) throws SQLException, DataAccessException {
		Emp e=new Emp();
		e.setEno(rs.getInt(1));
		e.setName(rs.getString(2));
		e.setAddress(rs.getString(3));
		return e;
	}

}
