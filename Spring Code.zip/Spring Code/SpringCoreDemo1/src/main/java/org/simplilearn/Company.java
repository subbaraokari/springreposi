package org.simplilearn;

public class Company {
	private int cid;
	private String companyName;
	private String loc;
	public Company() {
		// TODO Auto-generated constructor stub
	}
	public Company(int cid, String companyName, String loc) {
		super();
		this.cid = cid;
		this.companyName = companyName;
		this.loc = loc;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	
}
