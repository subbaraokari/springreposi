package org.simplilearn;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("spring-beans.xml");
		Emp emp=context.getBean(Emp.class,"e");
		Address address=emp.getAddress();
		Company company=emp.getCompany();
		System.out.println(emp.getEno()+"\t"+emp.getName());
		System.out.println(address.getDno()+"\t"+address.getStreetName()+"\t"+address.getLoc());
		System.out.println(company.getCid()+"\t"+company.getCompanyName()+"\t"+company.getLoc());
	}

}
